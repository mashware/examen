<?php
/**
 * Created by PhpStorm.
 * User: programador
 * Date: 19/04/18
 * Time: 13:02
 */

namespace App\Domain\Entity;

interface ApiGamaBlancaProveedorEntityRepositoryInterface
{
}