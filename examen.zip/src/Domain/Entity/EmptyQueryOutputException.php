<?php

namespace App\Domain\Entity;

class EmptyQueryOutputException extends \Exception
{

}